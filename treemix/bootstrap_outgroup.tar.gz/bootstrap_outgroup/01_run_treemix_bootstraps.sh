#!/bin/bash

~/bin/anaconda/bin/python2.7 bootstrap_treemix.py whtstbk_lcr_dk_join_pruned.treemix outgroup_bootstrap LC_NA 1000 5