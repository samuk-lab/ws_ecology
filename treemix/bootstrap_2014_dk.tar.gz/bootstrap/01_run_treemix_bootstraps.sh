#!/bin/bash

~/bin/anaconda/bin/python2.7 bootstrap_treemix.py whtstbk_outgroup_2014_pruned.treemix whtstbk_2014 DK_dk 1000 5